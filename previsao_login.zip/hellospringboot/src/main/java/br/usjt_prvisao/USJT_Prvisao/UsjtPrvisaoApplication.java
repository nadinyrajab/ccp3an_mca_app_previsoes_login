package br.usjt_prvisao.USJT_Prvisao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsjtPrvisaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsjtPrvisaoApplication.class, args);
	}

}
