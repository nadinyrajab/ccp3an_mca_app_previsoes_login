insert into previsao (dia,maxima,minima,humidade,descricao) values ('Quinta-feira',34,17,15,'Dia quente com UR estável');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('Sexta-feira',32,22,16,'Dia quente com UR estável');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('Sábado',33,16,12,'Dia quente com baixa UR');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('Domingo',19,12,13.5,'Dia com temperatura e UR baixa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('Segunda-feira',18,12,10,'Dia com temperatura e UR baixa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('Terça-feira',16,13,12,'Dia com temperatura e UR baixa');
insert into previsao (dia,maxima,minima,humidade,descricao) values ('Quarta-feira',22,14,13,'Dia quente com UR baixa');


insert into usuario (id, login, senha) values (1, 'admin', '12345');